<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "inspections".
 *
 * @property int $id
 * @property string $inspection_date
 * @property string $result
 * @property int $equipment_id
 * @property int $employee_id
 *
 * @property Employees $employees
 * @property Equipment $equipment
 */
class Inspections extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'inspections';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['inspection_date', 'result', 'equipment_id', 'employee_id'], 'required'],
            [['inspection_date'], 'safe'],
            [['equipment_id', 'employee_id'], 'integer'],
            [['result'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'inspection_date' => 'Inspection Date',
            'result' => 'Result',
            'equipment_id' => 'Equipment ID',
            'employee_id' => 'Employee ID',
        ];
    }

    /**
     * Gets query for [[Employees]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEmployees()
    {
        return $this->hasOne(Employees::class, ['id' => 'employee_id']);
    }

    /**
     * Gets query for [[Equipment]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEquipment()
    {
        return $this->hasOne(Equipment::class, ['id' => 'equipment_id']);
    }
}
