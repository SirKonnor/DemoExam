<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "employees".
 *
 * @property int $id
 * @property int $employee_id
 * @property string $full_name
 * @property string $position
 *
 * @property Failures[] $failures
 * @property Inspections $id0
 */
class Employees extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'employees';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['employee_id', 'full_name', 'position'], 'required'],
            [['employee_id'], 'integer'],
            [['full_name', 'position'], 'string', 'max' => 255],
            [['id'], 'exist', 'skipOnError' => true, 'targetClass' => Inspections::class, 'targetAttribute' => ['id' => 'employee_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'employee_id' => 'Employee ID',
            'full_name' => 'Full Name',
            'position' => 'Position',
        ];
    }

    /**
     * Gets query for [[Failures]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getFailures()
    {
        return $this->hasMany(Failures::class, ['employee_id' => 'id']);
    }

    /**
     * Gets query for [[Id0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getId0()
    {
        return $this->hasOne(Inspections::class, ['employee_id' => 'id']);
    }
}
