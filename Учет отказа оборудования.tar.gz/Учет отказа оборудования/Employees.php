<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "employees".
 *
 * @property int $id
 * @property string $Табельный номер
 * @property string $ФИО
 * @property string $Должность
 *
 * @property EquipmentFailures[] $equipmentFailures
 * @property TechnicalInspections[] $technicalInspections
 * @property User[] $users
 */
class Employees extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'employees';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Табельный номер', 'ФИО', 'Должность'], 'required'],
            [['Должность'], 'string'],
            [['Табельный номер'], 'string', 'max' => 20],
            [['ФИО'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'Табельный номер' => 'Табельный Номер',
            'ФИО' => 'Фио',
            'Должность' => 'Должность',
        ];
    }

    /**
     * Gets query for [[EquipmentFailures]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEquipmentFailures()
    {
        return $this->hasMany(EquipmentFailures::class, ['employee_id' => 'id']);
    }

    /**
     * Gets query for [[TechnicalInspections]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTechnicalInspections()
    {
        return $this->hasMany(TechnicalInspections::class, ['employee_id' => 'id']);
    }

    /**
     * Gets query for [[Users]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUsers()
    {
        return $this->hasMany(User::class, ['employee_id' => 'id']);
    }
}
