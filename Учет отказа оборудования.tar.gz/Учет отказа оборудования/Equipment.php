<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "equipment".
 *
 * @property int $id
 * @property string $Номер оборудования
 * @property string $Имя оборудования
 * @property int $department_id
 *
 * @property Departments $department
 * @property EquipmentFailures[] $equipmentFailures
 * @property TechnicalInspections $technicalInspections
 */
class Equipment extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'equipment';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Номер оборудования', 'Имя оборудования', 'department_id'], 'required'],
            [['department_id'], 'integer'],
            [['Номер оборудования'], 'string', 'max' => 20],
            [['Имя оборудования'], 'string', 'max' => 255],
            [['department_id'], 'exist', 'skipOnError' => true, 'targetClass' => Departments::class, 'targetAttribute' => ['department_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'Номер оборудования' => 'Номер Оборудования',
            'Имя оборудования' => 'Имя Оборудования',
            'department_id' => 'Department ID',
        ];
    }

    /**
     * Gets query for [[Department]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getDepartment()
    {
        return $this->hasOne(Departments::class, ['id' => 'department_id']);
    }

    /**
     * Gets query for [[EquipmentFailures]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEquipmentFailures()
    {
        return $this->hasMany(EquipmentFailures::class, ['equipment_id' => 'id']);
    }

    /**
     * Gets query for [[TechnicalInspections]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTechnicalInspections()
    {
        return $this->hasOne(TechnicalInspections::class, ['id' => 'id']);
    }
}
