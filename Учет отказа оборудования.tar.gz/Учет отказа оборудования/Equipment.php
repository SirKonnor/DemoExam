<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "equipment".
 *
 * @property int $id
 * @property int $equipment_number
 * @property string $equipment_name
 * @property int $department_id
 *
 * @property Departments $departments
 * @property Failures[] $failures
 * @property Inspections $id0
 */
class Equipment extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'equipment';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['equipment_number', 'equipment_name', 'department_id'], 'required'],
            [['equipment_number', 'department_id'], 'integer'],
            [['equipment_name'], 'string', 'max' => 255],
            [['id'], 'exist', 'skipOnError' => true, 'targetClass' => Inspections::class, 'targetAttribute' => ['id' => 'equipment_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'equipment_number' => 'Equipment Number',
            'equipment_name' => 'Equipment Name',
            'department_id' => 'Department ID',
        ];
    }

    /**
     * Gets query for [[Departments]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getDepartments()
    {
        return $this->hasOne(Departments::class, ['id' => 'department_id']);
    }

    /**
     * Gets query for [[Failures]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getFailures()
    {
        return $this->hasMany(Failures::class, ['equipment_id' => 'id']);
    }

    /**
     * Gets query for [[Id0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getId0()
    {
        return $this->hasOne(Inspections::class, ['equipment_id' => 'id']);
    }
}
