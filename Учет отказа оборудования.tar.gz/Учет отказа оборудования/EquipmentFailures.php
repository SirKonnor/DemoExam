<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "equipment_failures".
 *
 * @property int $id
 * @property int $equipment_id
 * @property string $Дата отказа
 * @property string $Причина отказа
 * @property int $employee_id
 *
 * @property Employees $employee
 * @property Equipment $equipment
 */
class EquipmentFailures extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'equipment_failures';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['equipment_id', 'Дата отказа', 'Причина отказа', 'employee_id'], 'required'],
            [['equipment_id', 'employee_id'], 'integer'],
            [['Дата отказа'], 'safe'],
            [['Причина отказа'], 'string', 'max' => 255],
            [['employee_id'], 'exist', 'skipOnError' => true, 'targetClass' => Employees::class, 'targetAttribute' => ['employee_id' => 'id']],
            [['equipment_id'], 'exist', 'skipOnError' => true, 'targetClass' => Equipment::class, 'targetAttribute' => ['equipment_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'equipment_id' => 'Equipment ID',
            'Дата отказа' => 'Дата Отказа',
            'Причина отказа' => 'Причина Отказа',
            'employee_id' => 'Employee ID',
        ];
    }

    /**
     * Gets query for [[Employee]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEmployee()
    {
        return $this->hasOne(Employees::class, ['id' => 'employee_id']);
    }

    /**
     * Gets query for [[Equipment]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEquipment()
    {
        return $this->hasOne(Equipment::class, ['id' => 'equipment_id']);
    }
}
