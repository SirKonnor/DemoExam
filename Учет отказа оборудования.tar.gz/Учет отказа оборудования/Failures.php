<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "failures".
 *
 * @property int $id
 * @property string $failure_date
 * @property int $equipment_id
 * @property int $employee_id
 *
 * @property Employees $employee
 * @property Equipment $equipment
 * @property FailureDetails $id0
 */
class Failures extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'failures';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['failure_date', 'equipment_id', 'employee_id'], 'required'],
            [['failure_date'], 'safe'],
            [['equipment_id', 'employee_id'], 'integer'],
            [['employee_id'], 'exist', 'skipOnError' => true, 'targetClass' => Employees::class, 'targetAttribute' => ['employee_id' => 'id']],
            [['equipment_id'], 'exist', 'skipOnError' => true, 'targetClass' => Equipment::class, 'targetAttribute' => ['equipment_id' => 'id']],
            [['id'], 'exist', 'skipOnError' => true, 'targetClass' => FailureDetails::class, 'targetAttribute' => ['id' => 'failure_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'failure_date' => 'Failure Date',
            'equipment_id' => 'Equipment ID',
            'employee_id' => 'Employee ID',
        ];
    }

    /**
     * Gets query for [[Employee]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEmployee()
    {
        return $this->hasOne(Employees::class, ['id' => 'employee_id']);
    }

    /**
     * Gets query for [[Equipment]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEquipment()
    {
        return $this->hasOne(Equipment::class, ['id' => 'equipment_id']);
    }

    /**
     * Gets query for [[Id0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getId0()
    {
        return $this->hasOne(FailureDetails::class, ['failure_id' => 'id']);
    }
}
