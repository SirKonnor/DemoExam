<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "technical_inspections".
 *
 * @property int $id
 * @property int $equipment_id
 * @property string $Дата осмотра
 * @property string $Результат осмотра
 * @property string $Причина отказа, если есть
 * @property int $employee_id
 *
 * @property Employees $employee
 * @property Equipment $id0
 */
class TechnicalInspections extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'technical_inspections';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['equipment_id', 'Дата осмотра', 'Результат осмотра', 'Причина отказа, если есть', 'employee_id'], 'required'],
            [['equipment_id', 'employee_id'], 'integer'],
            [['Дата осмотра'], 'safe'],
            [['Результат осмотра'], 'string'],
            [['Причина отказа, если есть'], 'string', 'max' => 255],
            [['id'], 'exist', 'skipOnError' => true, 'targetClass' => Equipment::class, 'targetAttribute' => ['id' => 'id']],
            [['employee_id'], 'exist', 'skipOnError' => true, 'targetClass' => Employees::class, 'targetAttribute' => ['employee_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'equipment_id' => 'Equipment ID',
            'Дата осмотра' => 'Дата Осмотра',
            'Результат осмотра' => 'Результат Осмотра',
            'Причина отказа, если есть' => 'Причина Отказа, Если Есть',
            'employee_id' => 'Employee ID',
        ];
    }

    /**
     * Gets query for [[Employee]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEmployee()
    {
        return $this->hasOne(Employees::class, ['id' => 'employee_id']);
    }

    /**
     * Gets query for [[Id0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getId0()
    {
        return $this->hasOne(Equipment::class, ['id' => 'id']);
    }
}
