-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Окт 02 2024 г., 11:45
-- Версия сервера: 10.4.32-MariaDB
-- Версия PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `Учет отказа оборудования`
--

-- --------------------------------------------------------

--
-- Структура таблицы `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `Номер участка` int(11) NOT NULL,
  `Название участка` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `departments`
--

INSERT INTO `departments` (`id`, `Номер участка`, `Название участка`) VALUES
(1, 1, 'Цех 1'),
(2, 2, 'Цех 2'),
(3, 3, 'Цех 3'),
(4, 4, 'Цех 4'),
(5, 5, 'Цех 5'),
(6, 6, 'Цех 6'),
(7, 7, 'Цех 7'),
(8, 8, 'Цех 8'),
(9, 9, 'Цех 9'),
(10, 10, 'Цех 10');

-- --------------------------------------------------------

--
-- Структура таблицы `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `Табельный номер` varchar(20) NOT NULL,
  `ФИО` varchar(255) NOT NULL,
  `Должность` enum('Мастер','Механик','Электрик','Инженер','Менеджер','Оператор','Техник','Грузчик','Администратор') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `employees`
--

INSERT INTO `employees` (`id`, `Табельный номер`, `ФИО`, `Должность`) VALUES
(1, 'T-001', 'Иванов Иван Иванович', 'Мастер'),
(2, 'T-002', 'Петров Петр Петрович', 'Механик'),
(3, 'T-003', 'Сидоров Сидор Сидорович', 'Электрик'),
(4, 'T-004', 'Кузнецов Николай Николаевич', 'Инженер'),
(5, 'T-005', 'Фролова Анастасия Сергеевна', 'Менеджер'),
(6, 'T-006', 'Смирнов Алексей Владимирович', 'Оператор'),
(7, 'T-007', 'Ковалев Игорь Артемович', 'Техник'),
(8, 'T-008', 'Соколова Ольга Павловна', 'Администратор'),
(9, 'T-009', 'Кольцов Руслан Арсланович', 'Грузчик'),
(10, 'T-010', 'Лебедев Сергей Николаевич', 'Техник');

-- --------------------------------------------------------

--
-- Структура таблицы `equipment`
--

CREATE TABLE `equipment` (
  `id` int(11) NOT NULL,
  `Номер оборудования` varchar(20) NOT NULL,
  `Имя оборудования` varchar(255) NOT NULL,
  `department_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `equipment`
--

INSERT INTO `equipment` (`id`, `Номер оборудования`, `Имя оборудования`, `department_id`) VALUES
(1, 'EQ-001', 'Станок токарный', 1),
(2, 'EQ-002', 'Станок фрезерный', 1),
(3, 'EQ-003', 'Станок сверлильный', 2),
(4, 'EQ-004', 'Лазерный резак', 2),
(5, 'EQ-005', 'Кран мостовой', 2),
(6, 'EQ-006', 'Погрузчик', 3),
(7, 'EQ-007', 'Насос', 4),
(8, 'EQ-008', 'Генератор', 4),
(9, 'EQ-009', 'Плиткорез', 5),
(10, 'EQ-010', 'Сварочный аппарат', 5);

-- --------------------------------------------------------

--
-- Структура таблицы `equipment_failures`
--

CREATE TABLE `equipment_failures` (
  `id` int(11) NOT NULL,
  `equipment_id` int(11) NOT NULL,
  `Дата отказа` date NOT NULL,
  `Причина отказа` varchar(255) NOT NULL,
  `employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `equipment_failures`
--

INSERT INTO `equipment_failures` (`id`, `equipment_id`, `Дата отказа`, `Причина отказа`, `employee_id`) VALUES
(1, 1, '2023-01-30', 'Износ деталей', 2),
(2, 2, '2023-02-16', 'Поломка привода', 3),
(3, 3, '2023-03-01', 'Заедание механизма', 4),
(4, 4, '2023-04-20', 'Неисправность электроники', 5),
(5, 5, '2023-05-15', 'Утечка масла', 6),
(6, 6, '2023-07-05', 'Разрушение основного корпуса', 7),
(7, 7, '2023-07-05', 'Не работает стартер', 8),
(8, 8, '2023-08-10', 'Техническая неисправность', 9),
(9, 9, '2023-09-15', 'Износ продукции', 10),
(10, 10, '2023-10-20', 'Некорректное использование', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `technical_inspections`
--

CREATE TABLE `technical_inspections` (
  `id` int(11) NOT NULL,
  `equipment_id` int(11) NOT NULL,
  `Дата осмотра` date NOT NULL,
  `Результат осмотра` enum('Годен','Передать в ремонт','Списать') NOT NULL,
  `Причина отказа, если есть` varchar(255) NOT NULL,
  `employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `technical_inspections`
--

INSERT INTO `technical_inspections` (`id`, `equipment_id`, `Дата осмотра`, `Результат осмотра`, `Причина отказа, если есть`, `employee_id`) VALUES
(1, 1, '2023-01-15', 'Годен', 'Отсутствует', 1),
(2, 2, '2023-01-16', 'Передать в ремонт', 'Сломан привод', 2),
(3, 3, '2023-02-10', 'Годен', 'Отсутствует', 3),
(4, 4, '2023-02-11', 'Списать', 'Не подлежит ремонту', 4),
(5, 5, '2023-03-06', 'Годен', 'Отсутствует', 5),
(6, 6, '2023-03-06', 'Передать в ремонт', 'Проблемы с двигателем', 6),
(7, 7, '2023-04-02', 'Годен', 'Отсутствует', 7),
(8, 8, '2023-04-03', 'Списать', 'Сильно изношен', 8),
(9, 9, '2023-05-10', 'Годен', 'Отсутствует', 9),
(10, 10, '2023-05-11', 'Передать в ремонт', 'Не запускается', 10);

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('Администратор','Сотрудник') NOT NULL,
  `employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `role`, `employee_id`) VALUES
(3, 'admin', 'root', 'Администратор', 8),
(4, 'employee1', 'password1', 'Сотрудник', 1),
(5, 'employee2', 'password2', 'Сотрудник', 2),
(6, 'employee3', 'password3', 'Сотрудник', 3),
(7, 'employee4', 'password4', 'Сотрудник', 4),
(8, 'employee5', 'password5', 'Сотрудник', 5),
(9, 'employee7', 'password7', 'Сотрудник', 7),
(10, 'employee8', 'password8', 'Сотрудник', 8),
(11, 'employee9', 'password9', 'Сотрудник', 9),
(12, 'employee10', 'password10', 'Сотрудник', 10);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`);

--
-- Индексы таблицы `equipment_failures`
--
ALTER TABLE `equipment_failures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `equipment_id` (`equipment_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Индексы таблицы `technical_inspections`
--
ALTER TABLE `technical_inspections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `equipment_id` (`equipment_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `equipment`
--
ALTER TABLE `equipment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `equipment_failures`
--
ALTER TABLE `equipment_failures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `technical_inspections`
--
ALTER TABLE `technical_inspections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `equipment`
--
ALTER TABLE `equipment`
  ADD CONSTRAINT `equipment_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`);

--
-- Ограничения внешнего ключа таблицы `equipment_failures`
--
ALTER TABLE `equipment_failures`
  ADD CONSTRAINT `equipment_failures_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`),
  ADD CONSTRAINT `equipment_failures_ibfk_2` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`id`);

--
-- Ограничения внешнего ключа таблицы `technical_inspections`
--
ALTER TABLE `technical_inspections`
  ADD CONSTRAINT `technical_inspections_ibfk_1` FOREIGN KEY (`id`) REFERENCES `equipment` (`id`),
  ADD CONSTRAINT `technical_inspections_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`);

--
-- Ограничения внешнего ключа таблицы `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
