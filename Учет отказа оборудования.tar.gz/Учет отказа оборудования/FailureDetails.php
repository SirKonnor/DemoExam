<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "failure_details".
 *
 * @property int $id
 * @property int $failure_id
 * @property int $reason_id
 *
 * @property FailureReasons $failureReasons
 * @property Failures $failures
 */
class FailureDetails extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'failure_details';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['failure_id', 'reason_id'], 'required'],
            [['failure_id', 'reason_id'], 'integer'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'failure_id' => 'Failure ID',
            'reason_id' => 'Reason ID',
        ];
    }

    /**
     * Gets query for [[FailureReasons]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getFailureReasons()
    {
        return $this->hasOne(FailureReasons::class, ['id' => 'reason_id']);
    }

    /**
     * Gets query for [[Failures]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getFailures()
    {
        return $this->hasOne(Failures::class, ['id' => 'failure_id']);
    }
}
