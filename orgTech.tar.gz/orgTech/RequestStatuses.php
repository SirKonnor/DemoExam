<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "requestStatuses".
 *
 * @property int $id_requestStatuses
 * @property string $requestStatuses
 *
 * @property Request $requestStatuses0
 */
class RequestStatuses extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'requestStatuses';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['requestStatuses'], 'required'],
            [['requestStatuses'], 'string', 'max' => 255],
            [['id_requestStatuses'], 'exist', 'skipOnError' => true, 'targetClass' => Request::class, 'targetAttribute' => ['id_requestStatuses' => 'RequestStatus_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_requestStatuses' => 'Id Request Statuses',
            'requestStatuses' => 'Request Statuses',
        ];
    }

    /**
     * Gets query for [[RequestStatuses0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRequestStatuses0()
    {
        return $this->hasOne(Request::class, ['RequestStatus_id' => 'id_requestStatuses']);
    }
}
