<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "orgTechTypes".
 *
 * @property int $id_orgTechTypes
 * @property string $orgTechType
 *
 * @property Request $orgTechTypes
 */
class OrgTechTypes extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'orgTechTypes';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['orgTechType'], 'required'],
            [['orgTechType'], 'string', 'max' => 255],
            [['id_orgTechTypes'], 'exist', 'skipOnError' => true, 'targetClass' => Request::class, 'targetAttribute' => ['id_orgTechTypes' => 'orgTechType_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_orgTechTypes' => 'Id Org Tech Types',
            'orgTechType' => 'Org Tech Type',
        ];
    }

    /**
     * Gets query for [[OrgTechTypes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getOrgTechTypes()
    {
        return $this->hasOne(Request::class, ['orgTechType_id' => 'id_orgTechTypes']);
    }
}
