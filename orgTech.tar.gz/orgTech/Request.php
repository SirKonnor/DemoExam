<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "request".
 *
 * @property int $id_request
 * @property string $StartDate
 * @property int $orgTechType_id
 * @property string $orgTechModel
 * @property string $ProblemDescryption
 * @property int $RequestStatus_id
 * @property string $CompletionDate
 * @property string $RepairParts
 * @property int $master_id
 * @property int $client_id
 *
 * @property User $client
 * @property Comments $comments
 * @property User $master
 * @property OrgTechTypes $orgTechTypes
 * @property RequestStatuses $requestStatuses
 */
class Request extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'request';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['StartDate', 'orgTechType_id', 'orgTechModel', 'ProblemDescryption', 'RequestStatus_id', 'CompletionDate', 'RepairParts', 'master_id', 'client_id'], 'required'],
            [['StartDate', 'CompletionDate'], 'safe'],
            [['orgTechType_id', 'RequestStatus_id', 'master_id', 'client_id'], 'integer'],
            [['orgTechModel', 'ProblemDescryption', 'RepairParts'], 'string', 'max' => 255],
            [['client_id'], 'unique'],
            [['client_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::class, 'targetAttribute' => ['client_id' => 'id']],
            [['master_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::class, 'targetAttribute' => ['master_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_request' => 'Id Request',
            'StartDate' => 'Start Date',
            'orgTechType_id' => 'Org Tech Type ID',
            'orgTechModel' => 'Org Tech Model',
            'ProblemDescryption' => 'Problem Descryption',
            'RequestStatus_id' => 'Request Status ID',
            'CompletionDate' => 'Completion Date',
            'RepairParts' => 'Repair Parts',
            'master_id' => 'Master ID',
            'client_id' => 'Client ID',
        ];
    }

    /**
     * Gets query for [[Client]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getClient()
    {
        return $this->hasOne(User::class, ['id' => 'client_id']);
    }

    /**
     * Gets query for [[Comments]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getComments()
    {
        return $this->hasOne(Comments::class, ['request_id' => 'id_request']);
    }

    /**
     * Gets query for [[Master]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getMaster()
    {
        return $this->hasOne(User::class, ['id' => 'master_id']);
    }

    /**
     * Gets query for [[OrgTechTypes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getOrgTechTypes()
    {
        return $this->hasOne(OrgTechTypes::class, ['id_orgTechTypes' => 'orgTechType_id']);
    }

    /**
     * Gets query for [[RequestStatuses]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRequestStatuses()
    {
        return $this->hasOne(RequestStatuses::class, ['id_requestStatuses' => 'RequestStatus_id']);
    }
}
